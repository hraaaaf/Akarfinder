# Patchs et tests de la revue V6.4.6 (non appliqués au dépôt)

Racine attendue : le dépôt, avec `scripts/pilots/mubawab-v646/` (commit 57c96ab du pack).

    patch -p1 --dry-run < patches/02_access_policy_403_429_and_main_exit_code.diff
    patch -p1 < patches/02_access_policy_403_429_and_main_exit_code.diff
    patch -p1 < patches/01_canary_evidence_exit_codes_ids.diff
    patch -p1 < patches/03_metric_integrity_status_aware_and_field_change_log.diff
    cp tests/test_v646_review_adversarial.py scripts/pilots/mubawab-v646/tests/
    cd scripts/pilots/mubawab-v646 && python3 -m unittest discover -s tests -v

Les tests « DOM réel » sont ignorés sauf si AKAR_REAL_DOM pointe vers la fixture épurée du 2026-11-01 (absente du pack).
Résultats mesurés lors de la revue : avant correctifs 65 tests / 9 échecs / 4 erreurs / 5 échecs attendus ; après : OK, 5 échecs attendus.
